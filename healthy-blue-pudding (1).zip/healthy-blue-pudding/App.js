import React, { useState } from 'react';
import {
  StatusBar,
  View,
  Text,
  Image,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Appearance,
  StyleSheet,
} from 'react-native';
import Message from './components/Message';
import Response from './components/Response';

export default function App() {
  const [inputText, setInputText] = useState('');
  const [chatData, setChatData] = useState([]);
  const [theme, setTheme] = useState(Appearance.getColorScheme());

  const takeCommand = (message) => {
    if (
      message.includes('hey') ||
      message.includes('hello') ||
      message.includes('hi')
    ) {
      const botResponse = { type: 'bot', text: `How may I help you?` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('painter')) {
      const botResponse = { type: 'bot', text: `Hail Hitler` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('b') || message.includes('B')) {
      const botResponse = { type: 'bot', text: `B fizz` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('google')) {
      window.location.href = 'https://google.com';
      const botResponse = { type: 'bot', text: `Opening Google...` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('youtube')) {
      window.location.href = 'https://youtube.com';
      const botResponse = { type: 'bot', text: `Opening Youtube...` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('facebook')) {
      window.location.href = 'https://facebook.com';
      const botResponse = { type: 'bot', text: `Opening Facebook...` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('instagram')) {
      window.location.href = 'https://instagram.com';
      const botResponse = { type: 'bot', text: `Opening Instagram...` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('music')) {
      window.location.href = 'https://open.spotify.com ';
      const botResponse = { type: 'bot', text: `Opening Spotify...` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('Friday')) {
      window.location.href = 'http://127.0.0.1:3000/Friday/index.html ';
      const botResponse = { type: 'bot', text: `Opening Friday...` };
      setChatData((prevChat) => [...prevChat, botResponse]);
    }
     else if (
      message.includes('what is') ||
      message.includes('who is') ||
      message.includes('what are')
    ) {
      window.location.href = `https://www.google.com/search?q=${message.replace(
        ' ',
        '+'
      )}`;
      const finalText =
        'This is what I found on the internet regarding ' + message;
      const botResponse = { type: 'bot', text: finalText };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('wikipedia')) {
      window.open(
        `https://en.wikipedia.org/wiki/${message
          .replace('wikipedia', '')
          .trim()}`,
        '_blank'
      );
      const finalText =
        'This is what I found on Wikipedia regarding ' + message;
      const botResponse = { type: 'bot', text: finalText };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('time')) {
      const time = new Date().toLocaleString(undefined, {
        hour: 'numeric',
        minute: 'numeric',
      });
      const finalText = 'The current time is ' + time;
      const botResponse = { type: 'bot', text: finalText };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('date')) {
      const date = new Date().toLocaleString(undefined, {
        month: 'short',
        day: 'numeric',
      });
      const finalText = "Today's date is " + date;
      const botResponse = { type: 'bot', text: finalText };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('calculator')) {
      window.open('Calculator:///');
      const finalText = 'Opening Calculator';
      const botResponse = { type: 'bot', text: finalText };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else if (message.includes('Whatsapp') || message.includes('whatsapp')) {
      window.open('Whatsapp:///');
      const finalText = 'Opening Whatsapp';
      const botResponse = { type: 'bot', text: finalText };
      setChatData((prevChat) => [...prevChat, botResponse]);
    } else {
      window.open(
        `https://www.google.com/search?q=${message.replace(' ', '+')}`,
        '_blank'
      );
      const finalText =
        'I found some information for ' + message + ' on Google';
      const botResponse = { type: 'bot', text: finalText };
      setChatData((prevChat) => [...prevChat, botResponse]);
    }
  };

  const handleSendMessage = () => {
    if (inputText.trim()) {
      const newMessage = { type: 'user', text: inputText };
      setChatData((prevChat) => [...prevChat, newMessage]);
      setInputText('');

      // Call takeCommand to process the user's message
      takeCommand(newMessage.text);
    }
  };
  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme === 'light' ? '#f5f5f5' : '#121212',
    },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 16,
      paddingTop: 36,
      paddingBottom: 8,
      backgroundColor: theme === 'light' ? '#6200ea' : '#1f1f1f',
    },
    headerText: {
      fontSize: 24,
      fontWeight: '800',
      color: theme === 'light' ? '#ffffff' : '#e0e0e0',
      marginLeft: 8,
    },
    icon: {
      width: 32,
      height: 32,
    },
    chatContainer: {
      flex: 1,
      paddingHorizontal: 16,
    },
    inputBar: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 8,
      borderTopWidth: 1,
      borderColor: theme === 'light' ? '#ddd' : '#303030',
      backgroundColor: theme === 'light' ? '#fff' : '#121212',
    },
    input: {
      flex: 1,
      backgroundColor: theme === 'light' ? '#fff' : '#303030',
      fontSize: 16,
      paddingVertical: 8,
      paddingHorizontal: 16,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: theme === 'light' ? '#ddd' : '#303030',
      marginRight: 8,
      color: theme === 'light' ? '#323232' : '#e0e0e0',
    },
    sendButton: {
      backgroundColor: theme === 'light' ? '#ff00ff' : '#1f1f1f',
      padding: 10,
      borderRadius: 20,
    },
    sendIcon: {
      width: 20,
      height: 20,
      tintColor: '#fff',
    },
    themeButton: {
      position: 'absolute',
      top: 40,
      right: 16,
      backgroundColor: theme === 'light' ? '#6200ea' : '#1f1f1f',
      padding: 0,
      borderRadius: 200,
      elevation: 2,
    },
    themeButtonText: {
      color: '#fff',
      fontWeight: 'bold',
    },
  });
  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar style={theme === 'light' ? 'auto' : 'light-content'} />

      {/* Header */}
      <View style={styles.header}>
        <Image
          source={require('./assets/snack-icon.png')}
          style={styles.icon}
        />
        <Text style={styles.headerText}>FRIDAY</Text>
      </View>

      {/* Theme Toggle Button */}
      <TouchableOpacity onPress={toggleTheme} style={styles.themeButton}>
        <Text style={styles.themeButtonText}>
          {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
        </Text>
      </TouchableOpacity>

      {/* Chat Content */}
      <FlatList
        style={styles.chatContainer}
        data={chatData}
        renderItem={({ item }) =>
          item.type === 'user' ? (
            <Message text={item.text} />
          ) : (
            <Response text={item.text} />
          )
        }
        keyExtractor={(item, index) => index.toString()}
      />

      {/* Input Bar */}
      <View style={styles.inputBar}>
        <TextInput
          placeholder="Type a message..."
          style={styles.input}
          value={inputText}
          onChangeText={setInputText}
          selectionColor={theme === 'light' ? '#323232' : '#e0e0e0'}
        />
        <TouchableOpacity onPress={handleSendMessage} style={styles.sendButton}>
          <Image
            source={require('./assets/snack-icon.png')}
            style={styles.sendIcon}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}
