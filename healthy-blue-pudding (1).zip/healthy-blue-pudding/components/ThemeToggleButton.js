
import React, { useState, useEffect } from 'react';
import { View, TouchableWithoutFeedback, StyleSheet, Animated, Easing } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const CustomToggleSwitch = ({ toggleTheme, isDarkMode }) => {
  const [animationValue] = useState(new Animated.Value(isDarkMode ? 1 : 0));

  useEffect(() => {
    Animated.timing(animationValue, {
      toValue: isDarkMode ? 1 : 0,
      duration: 300,
      easing: Easing.inOut(Easing.ease),
      useNativeDriver: false,
    }).start();
  }, [isDarkMode]);

  const toggleCirclePosition = animationValue.interpolate({
    inputRange: [0, 1],
    outputRange: [2, 32],
  });

  const backgroundColor = animationValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['#FFD1DC', '#B39EB5'],
  });

  return (
    <TouchableWithoutFeedback onPress={toggleTheme}>
      <Animated.View style={[styles.switch, { backgroundColor }]}>
        <Animated.View style={[styles.circle, { left: toggleCirclePosition }]}>
          {isDarkMode ? (
            <FontAwesome name="moon-o" size={18} color="#B39EB5" />
          ) : (
            <FontAwesome name="sun-o" size={18} color="#FFD1DC" />
          )}
        </Animated.View>
      </Animated.View>
    </TouchableWithoutFeedback>
  );
};

const styles = StyleSheet.create({
  switch: {
    width: 60,
    height: 34,
    borderRadius: 17,
    padding: 2,
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 5,
  },
  circle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
  },
});

export default CustomToggleSwitch;