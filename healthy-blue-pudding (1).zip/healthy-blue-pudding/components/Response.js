import React from "react";
import { View, Text, StyleSheet } from "react-native";

const Response = ({ text }) => {
  return (
    <View style={styles.responseContainer}>
      <Text style={styles.responseText}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  responseContainer: {
    alignSelf: "flex-start",
    backgroundColor: "#e0e0e0",
    borderRadius: 20,
    padding: 10,
    marginVertical: 5,
    maxWidth: "80%",
  },
  responseText: {
    color: "#323232",
    fontSize: 16,
  },
});

export default Response;
