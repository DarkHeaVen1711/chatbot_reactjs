import React from "react";
import { View, Text, StyleSheet } from "react-native";

const Message = ({ text }) => {
  return (
    <View style={styles.messageContainer}>
      <Text style={styles.messageText}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  messageContainer: {
    alignSelf: "flex-end",
    backgroundColor: "#6200ea",
    borderRadius: 20,
    padding: 10,
    marginVertical: 5,
    maxWidth: "80%",
  },
  messageText: {
    color: "#ffffff",
    fontSize: 16,
  },
});

export default Message;
